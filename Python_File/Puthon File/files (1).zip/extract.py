#!/usr/bin/env python3
"""
Upwork Problem-Discovery Extractor
-----------------------------------
Reads a CSV of raw Upwork job posts, sends each row to Claude for problem
analysis (per the B2B problem-discovery framework), applies a hard-gate
confidence cap in code (never trust the model alone for this), and writes
an enriched CSV with all analysis columns appended after the originals.

Usage:
    python3 extract.py
    (it will prompt you for the input CSV path)

    or

    python3 extract.py /path/to/input.csv
    python3 extract.py /path/to/input.csv /path/to/output.csv

Requires:
    GROQ_API_KEY environment variable set.
"""

import os
import sys
import json
import time
import csv as csv_module

import pandas as pd
from groq import Groq, APIError, APIStatusError

from prompts import SYSTEM_PROMPT, USER_TEMPLATE

# Good default: strong reasoning, fast, cheap. Swap for another Groq model
# name (e.g. "llama-3.1-8b-instant" for speed, or a newer model) if you want.
MODEL = "llama-3.3-70b-versatile"
MAX_RETRIES = 3
RETRY_BACKOFF_SECONDS = 5

REQUIRED_INPUT_COLUMNS = [
    "job_title",
    "job_description",
    "job_url",
    "client_payment_verified",
    "client_total_spend",
    "date_posted",
]

ANALYSIS_COLUMNS = [
    "PROBLEM_AWARENESS",
    "LEAD_TYPE",
    "PROBLEM_SCORE",
    "OPPORTUNITY_SCORE",
    "URGENCY_SCORE",
    "AUTOMATION_FIT_SCORE",
    "PAIN_SEVERITY",
    "BUSINESS_IMPACT",
    "TIME_WASTE",
    "FREQUENCY_VOLUME",
    "FINANCIAL_IMPACT",
    "SURFACE_REQUEST",
    "EXPLICIT_PROBLEM",
    "INFERRED_ROOT_PROBLEM",
    "BUSINESS_CONSEQUENCE",
    "POSSIBLE_SOLUTION_DIRECTION",
    "PROBLEM_HOOK",
    "EVIDENCE",
    "CONFIDENCE_SCORE",
    "FINAL_PRIORITY",
]

# Fields that, if ALL empty/null, mean there's no quantified pain in the
# post at all. In that case we override the model's confidence score down
# to a hard cap, no matter what it returned. This is enforced in code so
# the rule can never be skipped or talked around by the model.
QUANTIFICATION_FIELDS = ["BUSINESS_IMPACT", "TIME_WASTE", "FREQUENCY_VOLUME"]
HARD_GATE_CONFIDENCE_CAP = 40
HARD_GATE_SCORE_CAP = 40


def is_empty(value) -> bool:
    if value is None:
        return True
    s = str(value).strip().lower()
    return s in ("", "null", "none", "n/a", "na")


def get_client() -> Groq:
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        print("ERROR: GROQ_API_KEY environment variable is not set.")
        print("Set it with: export GROQ_API_KEY=your-key-here")
        print("(get a key at https://console.groq.com/keys)")
        sys.exit(1)
    return Groq(api_key=api_key)


def call_model(client: Groq, row: dict) -> dict:
    user_message = USER_TEMPLATE.format(
        job_title=row.get("job_title", ""),
        job_description=row.get("job_description", ""),
        client_payment_verified=row.get("client_payment_verified", ""),
        client_total_spend=row.get("client_total_spend", ""),
        date_posted=row.get("date_posted", ""),
    )

    last_error = None
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = client.chat.completions.create(
                model=MODEL,
                max_tokens=1500,
                temperature=0.2,
                response_format={"type": "json_object"},
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_message},
                ],
            )
            text = response.choices[0].message.content.strip()

            # Strip accidental markdown fences if the model adds them anyway
            if text.startswith("```"):
                text = text.strip("`")
                if text.startswith("json"):
                    text = text[4:]
                text = text.strip()

            return json.loads(text)

        except (APIError, APIStatusError) as e:
            last_error = e
            print(f"  API error on attempt {attempt}/{MAX_RETRIES}: {e}")
            time.sleep(RETRY_BACKOFF_SECONDS * attempt)
        except json.JSONDecodeError as e:
            last_error = e
            print(f"  JSON parse error on attempt {attempt}/{MAX_RETRIES}: {e}")
            time.sleep(RETRY_BACKOFF_SECONDS)

    raise RuntimeError(f"Failed after {MAX_RETRIES} attempts: {last_error}")


def apply_hard_gate(analysis: dict) -> dict:
    """Enforce the no-quantified-evidence -> low-confidence rule in code,
    regardless of what the model returned."""
    all_unquantified = all(is_empty(analysis.get(f)) for f in QUANTIFICATION_FIELDS)

    if all_unquantified:
        try:
            confidence = int(analysis.get("CONFIDENCE_SCORE") or 0)
        except (TypeError, ValueError):
            confidence = 0
        if confidence > HARD_GATE_CONFIDENCE_CAP:
            analysis["CONFIDENCE_SCORE"] = HARD_GATE_CONFIDENCE_CAP

        try:
            problem_score = int(analysis.get("PROBLEM_SCORE") or 0)
        except (TypeError, ValueError):
            problem_score = 0
        if problem_score > HARD_GATE_SCORE_CAP:
            analysis["PROBLEM_SCORE"] = HARD_GATE_SCORE_CAP

        # A lead with no quantified evidence can never be HOT_PROBLEM.
        if analysis.get("LEAD_TYPE") == "HOT_PROBLEM":
            analysis["LEAD_TYPE"] = "POTENTIAL_PROBLEM"

        # And it can never be top priority.
        if analysis.get("FINAL_PRIORITY") == "P1":
            analysis["FINAL_PRIORITY"] = "P3"

    return analysis


def validate_row(input_row: dict) -> list:
    missing = [c for c in REQUIRED_INPUT_COLUMNS if c not in input_row]
    return missing


def print_summary(enriched_rows: list):
    total = len(enriched_rows)
    if total == 0:
        print("\nNo rows processed.")
        return

    def score_of(r, key):
        try:
            return int(r.get(key) or 0)
        except (TypeError, ValueError):
            return 0

    strong = sum(1 for r in enriched_rows if score_of(r, "PROBLEM_SCORE") >= 70)
    weak = sum(1 for r in enriched_rows if score_of(r, "PROBLEM_SCORE") < 40)
    avg_problem = sum(score_of(r, "PROBLEM_SCORE") for r in enriched_rows) / total
    avg_opportunity = sum(score_of(r, "OPPORTUNITY_SCORE") for r in enriched_rows) / total

    has_financial_impact = sum(
        1 for r in enriched_rows
        if r.get("FINANCIAL_IMPACT") not in (None, "", "NO_CLEAR_FINANCIAL_IMPACT")
    )
    has_quantified_pain = sum(
        1 for r in enriched_rows
        if not all(is_empty(r.get(f)) for f in QUANTIFICATION_FIELDS)
    )

    print("\n" + "=" * 60)
    print("FINAL SUMMARY")
    print("=" * 60)
    print(f"Total leads analyzed:              {total}")
    print(f"Strong problem leads (score>=70):  {strong}")
    print(f"Weak/solution-only leads (<40):    {weak}")
    print(f"Average PROBLEM_SCORE:             {avg_problem:.1f}")
    print(f"Average OPPORTUNITY_SCORE:         {avg_opportunity:.1f}")
    print(f"% with measurable financial impact: {100*has_financial_impact/total:.0f}%")
    print(f"% with explicit quantified pain:    {100*has_quantified_pain/total:.0f}%")

    print("\nTop leads by FINAL_PRIORITY / PROBLEM_SCORE:")
    ranked = sorted(
        enriched_rows,
        key=lambda r: (r.get("FINAL_PRIORITY", "P4"), -score_of(r, "PROBLEM_SCORE")),
    )
    for r in ranked[:10]:
        print(
            f"  [{r.get('FINAL_PRIORITY')}] "
            f"score={score_of(r, 'PROBLEM_SCORE')} "
            f"- {r.get('job_title', '')[:60]}"
        )
    print("=" * 60)


def main():
    args = sys.argv[1:]

    if len(args) >= 1:
        input_path = args[0]
    else:
        input_path = input("Enter the path to your input CSV: ").strip().strip('"')

    if not os.path.isfile(input_path):
        print(f"ERROR: file not found: {input_path}")
        sys.exit(1)

    if len(args) >= 2:
        output_path = args[1]
    else:
        base, _ = os.path.splitext(input_path)
        output_path = f"{base}_enriched.csv"

    df = pd.read_csv(input_path, dtype=str).fillna("")
    input_rows = df.to_dict(orient="records")

    missing_cols = validate_row(input_rows[0]) if input_rows else REQUIRED_INPUT_COLUMNS
    if missing_cols:
        print(f"ERROR: input CSV is missing required columns: {missing_cols}")
        print(f"Required columns: {REQUIRED_INPUT_COLUMNS}")
        sys.exit(1)

    client = get_client()

    enriched_rows = []
    total = len(input_rows)
    print(f"Processing {total} rows from {input_path} ...")

    for i, row in enumerate(input_rows, start=1):
        title_preview = str(row.get("job_title", ""))[:50]
        print(f"[{i}/{total}] {title_preview}")

        try:
            analysis = call_model(client, row)
            analysis = apply_hard_gate(analysis)
        except Exception as e:
            print(f"  FAILED to analyze row {i}: {e}")
            analysis = {col: "ERROR" for col in ANALYSIS_COLUMNS}

        merged = dict(row)
        for col in ANALYSIS_COLUMNS:
            merged[col] = analysis.get(col, "")
        enriched_rows.append(merged)

        # Be polite to the API between calls
        time.sleep(0.5)

    fieldnames = REQUIRED_INPUT_COLUMNS + ANALYSIS_COLUMNS
    # Preserve any extra input columns beyond the required ones
    extra_cols = [c for c in df.columns if c not in REQUIRED_INPUT_COLUMNS]
    fieldnames = REQUIRED_INPUT_COLUMNS + extra_cols + ANALYSIS_COLUMNS

    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv_module.DictWriter(f, fieldnames=fieldnames, quoting=csv_module.QUOTE_ALL)
        writer.writeheader()
        for r in enriched_rows:
            writer.writerow({k: r.get(k, "") for k in fieldnames})

    print(f"\nDone. Enriched CSV written to: {output_path}")
    print_summary(enriched_rows)


if __name__ == "__main__":
    main()
